import pandas as pd

data = pd.read_csv("gesture_data.csv", header=None)

# remove a gesture (example: gun)
data = data[data[0] != "gun"]

data.to_csv("gesture_data.csv", index=False, header=False)

print("Gesture removed!")