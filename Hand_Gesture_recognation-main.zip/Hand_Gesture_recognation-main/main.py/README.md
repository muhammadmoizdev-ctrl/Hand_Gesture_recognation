# Hand Gesture Recognition

A real-time hand gesture recognition system using OpenCV, MediaPipe, and scikit-learn's K-Nearest Neighbors classifier.

## Features

- **Real-time hand detection** using MediaPipe
- **Gesture classification** with KNN machine learning model
- **Data collection** tool for creating custom gesture datasets
- **Easy to use** - works with webcam

## Project Structure

- `main.py` - Collect hand gesture data for training
- `train_modle.py` - Train the KNN model on collected data
- `predict.py` - Real-time gesture prediction using trained model
- `gesture_data.csv` - Training dataset with hand landmarks
- `gesture_model.pkl` - Trained model (binary format)

## Installation

1. Clone this repository:
```bash
git clone https://github.com/YOUR_USERNAME/hand-gesture-recognition.git
cd hand-gesture-recognition
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Step 1: Collect Training Data
Run the data collection script:
```bash
python main.py
```
- Enter a gesture label (e.g., "1", "2", "thumbs_up")
- Show your hand gesture to the webcam
- Press ESC to stop collecting

Repeat this step for different gestures you want to recognize.

### Step 2: Train the Model
Train the model with collected data:
```bash
python train_modle.py
```
This will display the model accuracy and save the trained model.

### Step 3: Predict Gestures
Run the prediction script to recognize gestures in real-time:
```bash
python predict.py
```
- Show your hand to the webcam
- The recognized gesture will be displayed on the screen
- Press ESC to exit

## Requirements

- Python 3.7+
- Webcam
- See `requirements.txt` for Python dependencies

## How It Works

1. **Hand Detection**: Uses MediaPipe to detect 21 hand landmarks (joints and fingertips)
2. **Feature Extraction**: Extracts x, y, z coordinates from each landmark (63 features total)
3. **Classification**: Uses K-Nearest Neighbors (KNN) to classify gestures
4. **Prediction**: Compares new hand positions to training data and predicts the closest match

## Customization

- Modify `n_neighbors` in `train_modle.py` to adjust KNN sensitivity
- Add more gesture labels in the data collection phase
- Increase training data for better accuracy

## License

MIT License

## Author

Your Name
